package dao;

import pojo.Buch;
import java.util.ArrayList;
import java.util.List;

public interface BuchDAO {
    final List<Buch> buchList = new ArrayList<>();

    public void buchHinzufügen(Buch buch);

    public void buchAktualisieren(Buch buch);

    public void buchEntfernen(int buchId) ;
       
    public Buch buchNachIdSuchen(int buchId) ;

    public List<Buch> alleBücherAbrufen();
}
