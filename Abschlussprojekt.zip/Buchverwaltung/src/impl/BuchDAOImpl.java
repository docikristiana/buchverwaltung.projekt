package impl;


import dao.BuchDAO;





import pojo.Buch;
import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class BuchDAOImpl implements BuchDAO {
 
	private String url = "jdbc:mysql://localhost:3306/buchverwaltung_db?createDatabaseIfNotExist=true";
	private String user = "root";
	private String passwort = "";
	
	public BuchDAOImpl(Connection connection) {
		// TODO Auto-generated constructor stub
	}

	private Connection getConnection() throws SQLException {
		return DriverManager.getConnection(url,user,passwort);
		
	}

    public void buchHinzufügen(Buch buch) {
        String query = "INSERT INTO bücher (titel, autor, jahr, isbn) VALUES (?, ?, ?, ?)";
        try  (Connection connection= getConnection();PreparedStatement statement = connection.prepareStatement(query,Statement.RETURN_GENERATED_KEYS)) {
            statement.setString(1, buch.getTitel());
            statement.setString(2, buch.getAutor());
            statement.setInt(3, buch.getJahr());
            statement.setString(4, buch.getIsbn());
            statement.executeUpdate(); 
            
            ResultSet rs= statement.getGeneratedKeys();
            rs.next();
            int buchId=rs.getInt(1);
            buch.setbuchId(buchId);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    
    public void buchAktualisieren(Buch buch) {
        String query = "UPDATE bücher SET titel = ?, autor = ?, jahr = ?, isbn = ? WHERE buchId = ?";
        try  (Connection connection= getConnection();PreparedStatement statement = connection.prepareStatement(query)) {
        	   statement.setString(1, buch.getTitel());
               statement.setString(2, buch.getAutor());
               statement.setInt(3, buch.getJahr());
               statement.setString(4, buch.getIsbn());
               statement.setInt(5, buch.getbuchId());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void buchEntfernen(Buch buch) {
        String query = "DELETE FROM bücher WHERE isbn = ?";
        try  (Connection connection= getConnection();PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, buch.getIsbn());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void buchEntfernen(int buchId) {
        String query = "DELETE FROM bücher WHERE buchId = ?";
        try  (Connection connection= getConnection();PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, buchId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public Buch buchNachIdSuchen(int buchId) {
        String query = "SELECT * FROM bücher WHERE buchId = ?";
        try  (Connection connection= getConnection();PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, buchId);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return new Buch(
                        resultSet.getString("titel"),
                        resultSet.getString("autor"),
                        resultSet.getInt("jahr"),
                        resultSet.getString("isbn")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

 
    public List<Buch> alleBücherAbrufen() {
        List<Buch> books = new ArrayList<>();
        String query = "SELECT * FROM bücher";
        try  (Connection connection= getConnection();PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                books.add(new Buch(
                        resultSet.getString("titel"),
                        resultSet.getString("autor"),
                        resultSet.getInt("jahr"),
                        resultSet.getString("isbn")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return books;
    }
}

