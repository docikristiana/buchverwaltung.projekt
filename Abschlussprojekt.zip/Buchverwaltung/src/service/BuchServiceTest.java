package service;

import pojo.Buch;
import service.BuchService;
import dao.BuchDAO;
import impl.BuchDAOImpl;

import java.util.List;

public class BuchServiceTest {

    public static void main(String[] args) {
        // Step 1: Set up the DAO and Service
        BuchDAO buchDAO = new BuchDAOImpl(null);
        BuchService buchService = new BuchService(buchDAO);

        // Step 2: Create and add books
        Buch buch1 = new Buch(1, "Java Programming", "John Doe", 2021);
        Buch buch2 = new Buch(2, "Advanced Java", "Jane Smith", 2022);
        Buch buch3 = new Buch(3, "Java for Beginners", "John Doe", 2020);

        buchService.buchHinzufügen(buch1);
        buchService.buchHinzufügen(buch2);
        buchService.buchHinzufügen(buch3);

        // Step 3: Retrieve all books and print them
        List<Buch> alleBücher = buchService.alleBücherAbrufen();
        System.out.println("Alle Bücher:");
        for (Buch buch : alleBücher) {
            System.out.println(buch.getTitel());
        }

        // Step 4: Update a book
        buch2.setTitel("Advanced Java - Updated");
        buchService.buchAktualisieren(buch2);

        // Step 5: Retrieve the book by ID and print
        Buch updatedBuch = buchService.buchNachIdSuchen(2);
        if (updatedBuch != null) {
            System.out.println("Aktualisiertes Buch: " + updatedBuch.getTitel());
        }

        // Step 6: Remove a book
        buchService.buchEntfernen(1);

        // Step 7: Retrieve all books after removal
        alleBücher = buchService.alleBücherAbrufen();
        System.out.println("Alle Bücher nach Entfernen eines Buches:");
        for (Buch buch : alleBücher) {
            System.out.println(buch.getTitel());
        }
    }
}
