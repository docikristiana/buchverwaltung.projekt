package verbindung;

import pojo.Buch;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class LesenAusDatenbankTest {

	public static void main(String[] args) throws SQLException {
		String url = "jdbc:mysql://localhost:3306/buchverwaltung_db?createDatabaseIfNotExist=true";
		String user = "root";
		String passwort = "";
		
		Connection verbindung = DriverManager.getConnection(url, user, passwort);
		System.out.println(verbindung);
		
		String sqlLesen = "SELECT * FROM bücher";
		Statement uebersetzer = verbindung.createStatement();
		
		ResultSet antwort = uebersetzer.executeQuery(sqlLesen);
		while(antwort.next()) {
			int buchId = antwort.getInt("buchId");
			String titel = antwort.getString("titel");
			String autor = antwort.getString("autor");
			int jahr = antwort.getInt("jahr");
			String isbn = antwort.getString("isbn");
		
			
			Buch ausDb = new Buch(titel,autor,jahr,isbn);
			ausDb.setbuchId(buchId);
			System.out.println(ausDb);
		}
		
	}

}
