package impl;

import impl.BuchDAOImpl;



import pojo.Buch;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

public class BuchDAOImplTest {

    private static Connection connection;
    private static BuchDAOImpl buchDAO;

    // Verbindung zur Datenbank herstellen (Testdatenbank)
    public static void setUp() throws SQLException {
        // Verbindung zur Test-Datenbank herstellen
        connection = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/buchverwaltung_db?createDatabaseIfNotExist=true", 
                "root", 
                ""
        );
        buchDAO = new BuchDAOImpl(connection);
        Buch buch = new Buch("Die Unendliche Geschichte", "Michael Ende", 1979, "978-3-123456-78-9");
        // Testdatenbank aufräumen, bevor der Test startet
        buchDAO.buchEntfernen(buch); // Löscht Buch mit ID 37, falls es existiert
    }

    // Test für das Hinzufügen eines Buches
    public static void testBuchHinzufuegen() throws SQLException {
        setUp();

        // Ein Buch hinzufügen
        Buch buch = new Buch("Die Unendliche Geschichte", "Michael Ende", 1979, "978-3-123456-78-9");
        buchDAO.buchHinzufügen(buch);

         //Überprüfen, ob das Buch in der Datenbank existiert
        Buch buchGefunden = buchDAO.buchNachIdSuchen(buch.getbuchId());
       if (buchGefunden != null && buchGefunden.getTitel().equals("Die Unendliche Geschichte")) {
        	
            System.out.println("Test erfolgreich: Buch wurde hinzugefügt.");
       } else {
           System.out.println("Test fehlgeschlagen: Buch wurde nicht hinzugefügt.");
        }
   }

    // Test für das Abrufen aller Bücher
    public static void testAlleBuecherAbrufen() throws SQLException {
        setUp();

        // Ein Buch hinzufügen
        Buch buch = new Buch("Die Unendliche Geschichte", "Michael Ende", 1979, "978-3-123456-78-9");
        buchDAO.buchHinzufügen(buch);

        // Alle Bücher abrufen und überprüfen, ob das Buch hinzugefügt wurde
        List<Buch> buecher = buchDAO.alleBücherAbrufen();
        boolean buchGefunden = buecher.stream()
            .anyMatch(b -> b.getTitel().equals("Die Unendliche Geschichte"));
        
        if (buchGefunden) {
            System.out.println("Test erfolgreich: Buch wurde in der Liste gefunden.");
        } else {
            System.out.println("Test fehlgeschlagen: Buch wurde nicht in der Liste gefunden.");
        }
    }

    // Test für das Aktualisieren eines Buches
    public static void testBuchAktualisieren() throws SQLException {
        setUp();

        // Ein Buch hinzufügen
        Buch buch = new Buch("Die Unendliche Geschichte", "Michael Ende", 1979, "978-3-123456-78-9");
        buchDAO.buchHinzufügen(buch);

        // Buch aktualisieren
        Buch buchZuAktualisieren = buchDAO.buchNachIdSuchen(buch.getbuchId());
        buchZuAktualisieren.setTitel("Die Unendliche Geschichte (Aktualisiert)");
        buchDAO.buchAktualisieren(buchZuAktualisieren);

        // Überprüfen, ob das Buch erfolgreich aktualisiert wurde
        Buch buchAktualisiert = buchDAO.buchNachIdSuchen(buch.getbuchId());
        if (buchAktualisiert != null && buchAktualisiert.getTitel().equals("Die Unendliche Geschichte (Aktualisiert)")) {
            System.out.println("Test erfolgreich: Buch wurde aktualisiert.");
        } else {
            System.out.println("Test fehlgeschlagen: Buch wurde nicht aktualisiert.");
        }
    }

    // Test für das Entfernen eines Buches
    public static void testBuchEntfernen() throws SQLException {
        setUp();

        // Ein Buch hinzufügen
        Buch buch = new Buch("Die Unendliche Geschichte", "Michael Ende", 1979, "978-3-123456-78-9");
        buchDAO.buchHinzufügen(buch);

        // Buch entfernen
        buchDAO.buchEntfernen(buch.getbuchId());

        // Überprüfen, ob das Buch entfernt wurde
        Buch buchNachEntfernen = buchDAO.buchNachIdSuchen(buch.getbuchId());
        if (buchNachEntfernen == null) {
            System.out.println("Test erfolgreich: Buch wurde entfernt.");
        } else {
            System.out.println("Test fehlgeschlagen: Buch wurde nicht entfernt.");
        }
    }

    // Hauptfunktion zum Ausführen der Tests
    public static void main(String[] args) throws SQLException {
        testBuchHinzufuegen();
       testAlleBuecherAbrufen();
        testBuchAktualisieren();
        testBuchEntfernen();
    }
}
