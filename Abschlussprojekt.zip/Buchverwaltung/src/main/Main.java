package main;


import ui.KonsoleUI;


import dao.BuchDAO;
import impl.BuchDAOImpl;
import service.BuchService;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Main {
	

	    public static void main(String[] args) {
	      
	        try {
	            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/buchverwaltung_db", "root", "");

	            // Erstellen der DAO und des Service
	            BuchDAOImpl buchDAO = new BuchDAOImpl(connection);
	            BuchService buchService = new BuchService(buchDAO);

	            // Starten der Konsole
	            KonsoleUI consoleUI = new KonsoleUI(buchService);
	            consoleUI.start();

	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	}

