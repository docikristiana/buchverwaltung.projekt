package ui;

import pojo.Buch;
import service.BuchService;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.List;

public class KonsoleUITest {

    public static void main(String[] args) {
        // Create a mock BuchService
        BuchService buchService = new BuchService(null) {
            private List<Buch> buecher = Arrays.asList(
                    new Buch("Buch 1", "Autor 1", 2020, "12345"),
                    new Buch("Buch 2", "Autor 2", 2021, "67890")
            );

            @Override
            public List<Buch> alleBücherAbrufen() {
                return buecher;
            }

            @Override
            public void buchHinzufügen(Buch buch) {
                System.out.println("Buch hinzugefügt: " + buch.getTitel());
            }

            @Override
            public void buchEntfernen(int buchId) {
                System.out.println("Buch entfernt mit ID: " + buchId);
            }

            @Override
            public void buchAktualisieren(Buch buch) {
                System.out.println("Buch aktualisiert: " + buch.getTitel());
            }
        };

        // Create an instance of KonsoleUI with the mock service
        KonsoleUI konsoleUI = new KonsoleUI(buchService);

        // Test case 1: Option 1 (Show all books)
        testOption1(konsoleUI);

        // Test case 2: Option 2 (Add a book)
        testOption2(konsoleUI);

        // Test case 3: Option 3 (Remove a book)
        testOption3(konsoleUI);

        // Test case 4: Option 4 (Update a book)
        testOption4(konsoleUI);
    }

    private static void testOption1(KonsoleUI konsoleUI) {
        // Simulate user input for option 1 (Show all books)
        String input = "1\n"; // User selects option 1
        TestScanner testScanner = new TestScanner(input);

        // Capture output
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(outputStream);
        System.setOut(printStream);

        // Call the method
        konsoleUI.start();

        // Validate the output
        String expectedOutput = "1. Alle Bücher anzeigen\n" +
                "2. Buch hinzufügen\n" +
                "3. Buch entfernen\n" +
                "4. Buch aktualisieren\n" +
                "5. Beenden\n" +
                "Wählen Sie eine Option: Buch 1 von Autor 1\n" +
                "Buch 2 von Autor 2\n";

        String actualOutput = outputStream.toString();
        if (expectedOutput.equals(actualOutput)) {
            System.out.println("Option 1 test passed.");
        } else {
            System.out.println("Option 1 test failed.");
            System.out.println("Expected: \n" + expectedOutput);
            System.out.println("Actual: \n" + actualOutput);
        }
    }

    private static void testOption2(KonsoleUI konsoleUI) {
        // Simulate user input for option 2 (Add a book)
        String input = "2\nNeues Buch\nNeuer Autor\n2023\n112233\n"; // User selects option 2 and enters book details
        TestScanner testScanner = new TestScanner(input);

        // Capture output
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(outputStream);
        System.setOut(printStream);

        // Call the method
        konsoleUI.start();

        // Validate the output
        String expectedOutput = "1. Alle Bücher anzeigen\n" +
                "2. Buch hinzufügen\n" +
                "3. Buch entfernen\n" +
                "4. Buch aktualisieren\n" +
                "5. Beenden\n" +
                "Wählen Sie eine Option: Buch hinzugefügt: Neues Buch\n";

        String actualOutput = outputStream.toString();
        if (expectedOutput.equals(actualOutput)) {
            System.out.println("Option 2 test passed.");
        } else {
            System.out.println("Option 2 test failed.");
            System.out.println("Expected: \n" + expectedOutput);
            System.out.println("Actual: \n" + actualOutput);
        }
    }

    private static void testOption3(KonsoleUI konsoleUI) {
        // Simulate user input for option 3 (Remove a book)
        String input = "3\n1\n"; // User selects option 3 and enters book ID to remove
        TestScanner testScanner = new TestScanner(input);

        // Capture output
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(outputStream);
        System.setOut(printStream);

        // Call the method
        konsoleUI.start();

        // Validate the output
        String expectedOutput = "1. Alle Bücher anzeigen\n" +
                "2. Buch hinzufügen\n" +
                "3. Buch entfernen\n" +
                "4. Buch aktualisieren\n" +
                "5. Beenden\n" +
                "Wählen Sie eine Option: Buch entfernt mit ID: 1\n";

        String actualOutput = outputStream.toString();
        if (expectedOutput.equals(actualOutput)) {
            System.out.println("Option 3 test passed.");
        } else {
            System.out.println("Option 3 test failed.");
            System.out.println("Expected: \n" + expectedOutput);
            System.out.println("Actual: \n" + actualOutput);
        }
    }

    private static void testOption4(KonsoleUI konsoleUI) {
        // Simulate user input for option 4 (Update a book)
        String input = "4\n1\nAktualisierter Titel\nAktualisierter Autor\n2025\n54321\n"; // User selects option 4 and enters updated book details
        TestScanner testScanner = new TestScanner(input);

        // Capture output
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(outputStream);
        System.setOut(printStream);

        // Call the method
        konsoleUI.start();

        // Validate the output
        String expectedOutput = "1. Alle Bücher anzeigen\n" +
                "2. Buch hinzufügen\n" +
                "3. Buch entfernen\n" +
                "4. Buch aktualisieren\n" +
                "5. Beenden\n" +
                "Wählen Sie eine Option: Buch aktualisiert: Aktualisierter Titel\n";

        String actualOutput = outputStream.toString();
        if (expectedOutput.equals(actualOutput)) {
            System.out.println("Option 4 test passed.");
        } else {
            System.out.println("Option 4 test failed.");
            System.out.println("Expected: \n" + expectedOutput);
            System.out.println("Actual: \n" + actualOutput);
        }
    }

    // Custom TestScanner to simulate user input
    static class TestScanner {
        private final String input;
        private int index = 0;

        public TestScanner(String input) {
            this.input = input;
        }

        public String nextLine() {
            return String.valueOf(input.charAt(index++));
        }

        public int nextInt() {
            int next = Integer.parseInt(String.valueOf(input.charAt(index++)));
            return next;
        }
    }
}
