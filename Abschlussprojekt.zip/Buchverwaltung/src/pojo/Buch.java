package pojo;

import java.util.Objects;


public class Buch {
    private int buchId;
    private String titel;
    private String autor;
    private int jahr;
    private String isbn;

   
    public Buch(String string, String autor, int i, String string2) {
        this.titel = string;
        this.autor = autor;
        this.jahr = i;
        this.isbn = string2;
    }

    

	public Buch(int i, String string, String string2) {
		// TODO Auto-generated constructor stub
	}



	public Buch(int i, String autor2, String string, int j) {
		// TODO Auto-generated constructor stub
	}



	public int getbuchId() {
        return buchId;
    }

    public void setbuchId(int buchId) {
        this.buchId = buchId;
    }

    public String getTitel() {
        return titel;
    }

    public void setTitel(String titel) {
        this.titel = titel;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getJahr() {
        return jahr;
    }

    public void setJahr(int jahr) {
        this.jahr = jahr;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }
}


