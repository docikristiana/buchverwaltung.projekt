package pojo;

public class BuchTest {

    public static void main(String[] args) {
        // Test 1: Erstelle ein Buch
        Buch buch1 = new Buch("Der Hobbit", "J.R.R. Tolkien", 1937, "978-3-16-148410-0");

        // Ausgabe des Buches vor Änderungen
        System.out.println("Test 1: Erstelltes Buch - " + buch1);

        // Test 2: Setzen der ID
        buch1.setbuchId(1);
        System.out.println("Test 2: ID gesetzt - " + buch1.getbuchId());

        // Test 3: Getter und Setter für Titel, Autor, Jahr und ISBN testen
        buch1.setTitel("Der Herr der Ringe");
        buch1.setAutor("J.R.R. Tolkien");
        buch1.setJahr(1954);
        buch1.setIsbn("978-3-16-148410-1");

        // Ausgabe des Buches nach Änderungen
        System.out.println("Test 3: Geändertes Buch - ");
        System.out.println("Titel: " + buch1.getTitel());
        System.out.println("Autor: " + buch1.getAutor());
        System.out.println("Jahr: " + buch1.getJahr());
        System.out.println("ISBN: " + buch1.getIsbn());

        // Test 4: Überprüfen der Getter und Setter
        // Stellen Sie sicher, dass die Werte korrekt gesetzt wurden.
        if (buch1.getTitel().equals("Der Herr der Ringe") &&
            buch1.getAutor().equals("J.R.R. Tolkien") &&
            buch1.getJahr() == 1954 &&
            buch1.getIsbn().equals("978-3-16-148410-1")) {
            System.out.println("Test 4: Alle Werte wurden korrekt gesetzt.");
        } else {
            System.out.println("Test 4: Fehler beim Setzen der Werte.");
        }

        // Test 5: Erstellen eines weiteren Buches
        Buch buch2 = new Buch("1984", "George Orwell", 1949, "978-0-452-28423-4");
        buch2.setbuchId(2);
        System.out.println("Test 5: Zweites Buch - " + buch2);
    }
}

