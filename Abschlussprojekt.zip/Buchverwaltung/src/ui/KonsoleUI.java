package ui;


import pojo.Buch;
import service.BuchService;

import java.util.List;
import java.util.Scanner;

public class KonsoleUI {
    private final BuchService buchService;

    public KonsoleUI(BuchService buchService) {
        this.buchService = buchService;
    }

    public void start() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("1. Alle Bücher anzeigen");
            System.out.println("2. Buch hinzufügen");
            System.out.println("3. Buch entfernen");
            System.out.println("4. Buch aktualisieren");
            System.out.println("5. Beenden");
            System.out.print("Wählen Sie eine Option: ");

            int option = scanner.nextInt();
            scanner.nextLine(); 

            switch (option) {
                case 1:
                    List<Buch> buecher = buchService.alleBücherAbrufen();
                    for (Buch buch : buecher) {
                        System.out.println(buch.getTitel() + " von " + buch.getAutor());
                    }
                    break;
                case 2:
                    System.out.print("Titel: ");
                    String titel = scanner.nextLine();
                    System.out.print("Autor: ");
                    String autor = scanner.nextLine();
                    System.out.print("Jahr: ");
                    int jahr = scanner.nextInt();
                    System.out.print("ISBN: ");
                    scanner.nextLine(); 
                    String isbn = scanner.nextLine();
                    Buch buch = new Buch(titel, autor, jahr, isbn);
                    buchService.buchHinzufügen(buch);
                    break;
                case 3:
                    System.out.print("Geben Sie die ID des zu entfernenden Buches ein: ");
                    int id = scanner.nextInt();
                    buchService.buchEntfernen(id);
                    break;
                case 4:
                    System.out.print("Geben Sie die ID des zu aktualisierenden Buches ein: ");
                    int updateId = scanner.nextInt();
                    scanner.nextLine(); 
                    System.out.print("Neuer Titel: ");
                    String neuerTitel = scanner.nextLine();
                    System.out.print("Neuer Autor: ");
                    String neuerAutor = scanner.nextLine();
                    System.out.print("Neues Jahr: ");
                    int neuesJahr = scanner.nextInt();
                    System.out.print("Neue ISBN: ");
                    scanner.nextLine(); 
                    String neueIsbn = scanner.nextLine();
                    Buch aktualisiertesBuch = new Buch(neuerTitel, neuerAutor, neuesJahr, neueIsbn);
                    aktualisiertesBuch.setbuchId(updateId);
                    buchService.buchAktualisieren(aktualisiertesBuch);
                    break;
                case 5:
                    System.out.println("Beenden...");
                    return;
                default:
                    System.out.println("Ungültige Auswahl!");
            }
        }
    }
}
