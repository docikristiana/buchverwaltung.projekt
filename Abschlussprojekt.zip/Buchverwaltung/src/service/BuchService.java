package service;

import pojo.Buch;
import dao.BuchDAO;

import java.util.List;

public class BuchService {
    private final BuchDAO buchDAO;

    public BuchService(BuchDAO buchDAO) {
        this.buchDAO = buchDAO;
    }

    public void buchHinzufügen(Buch buch) {
        buchDAO.buchHinzufügen(buch);
    }

    public void buchAktualisieren(Buch buch) {
        buchDAO.buchAktualisieren(buch);
    }

    public void buchEntfernen(int buchId) {
        buchDAO.buchEntfernen(buchId);
    }

    public Buch buchNachIdSuchen(int buchId) {
        return buchDAO.buchNachIdSuchen(buchId);
    }

    public List<Buch> alleBücherAbrufen() {
        return buchDAO.alleBücherAbrufen();
    }
}
